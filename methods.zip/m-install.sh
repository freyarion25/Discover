#!/bin/bash
set -e
handle_apt_lock() {
    echo "Menghadapi error lock file, membersihkan..."
    sudo kill -9 $(ps aux | grep -i 'unattended-upgr' | awk '{print $2}') 2>/dev/null || true
    sudo rm -f /var/lib/dpkg/lock-frontend
    sudo rm -f /var/lib/dpkg/lock
    sudo rm -f /var/cache/apt/archives/lock
    sudo rm -f /var/lib/apt/lists/lock
    sudo dpkg --configure -a
}
echo "Menginstall venv"
if ! sudo apt install python3.12-venv -y; then
    handle_apt_lock
    sudo apt install python3.12-venv -y
fi
python3 -m venv myenv
source myenv/bin/activate
echo "Menginstall pip"
source myenv/bin/activate
if ! sudo apt install python3-pip -y; then
    handle_apt_lock
    sudo apt install python3-pip -y
fi
echo "Memulai instalasi modul python"
source myenv/bin/activate
pip install bs4
pip install requests colorama tqdm pyfiglet
echo "Memulai instalasi script..."
echo "Menginstall dependencies sistem..."
echo "Menginstall PM2 secara global"
if ! npm i pm2 -g; then
    echo "Gagal install PM2, mencoba dengan sudo..."
    sudo npm i pm2 -g
fi
echo "Menginstall modul npm..."
npm i cloudscraper axios cheerio colors commander express header-generator hpack http-proxy-agent http2-wrapper https-proxy-agent jsdom node-fetch randomstring socks socks-proxy-agent user-agents
echo "Instalasi selesai!"
echo "Memulai integrasi API (pm2)"
pm2 start api.js
pm2 list
echo "nyalain auto reboot 24h"
chmod +x cleaner.sh
bash cleaner.sh
echo "API berhasil dimulai"
echo "Dependencies sistem telah terinstall"
echo "PM2 telah terinstall secara global"
echo "Semua modul npm telah terinstall di direktori saat ini"