#!/bin/bash

# Script Pembersih VPS ala Nom
# - Bersihin cache tiap 1 jam
# - Restart VPS tiap jam 12 malem WIB
# - Auto jalanin PM2 abis restart
# - Mastiin cleaner tetep jalan abis restart

# File log buat nyimpen jejak
FILE_LOG="/var/log/cleaner.log"

# Path ke PM2 dan aplikasi
PM2_PATH="/usr/local/bin/pm2"
API_PATH="/root/api.js"

# Fungsi buat nulis log
tulis_log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$FILE_LOG"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# Fungsi buat bersihin folder cache
bersihin_cache() {
    tulis_log "Mulai bersihin folder cache..."
    
    # Daftar folder yang mau dibersihin
    FOLDER_SAMPAH=(
        "/var/cache/"
        "/tmp/"
        "/var/tmp/"
        "/root/.cache/"
        "/var/log/"
    )
    
    # Ukuran file minimal yang mau dihapus (dalam MB)
    UKURAN_MINIMAL=100
    
    for folder in "${FOLDER_SAMPAH[@]}"; do
        if [ -d "$folder" ]; then
            tulis_log "Bersihin folder: $folder"
            
            # Cari file gede
            FILE_GEDE=$(find "$folder" -type f -size +"$UKURAN_MINIMAL"M 2>/dev/null)
            
            if [ -n "$FILE_GEDE" ]; then
                tulis_log "Nemu file gede di $folder:"
                tulis_log "$FILE_GEDE"
                
                # Hapus file gede
                find "$folder" -type f -size +"$UKURAN_MINIMAL"M -delete 2>/dev/null
                tulis_log "Udah dihapus tuh file gede dari $folder"
            else
                tulis_log "Ga ada file gede di $folder, udah bersih keknya"
            fi
        else
            tulis_log "Folder $folder ga ada, skip aja lah"
        fi
    done
    
    tulis_log "Beres dah bersihin cache"
}

# Fungsi buat hapus file ga penting yang gede
hapus_file_sampah() {
    tulis_log "Mulai nyari file sampah yang gede..."
    
    # Pola file yang dianggep sampah
    POLA_SAMPAH=(
        "*.log"
        "*.log.*"
        "*.tmp"
        "*.bak"
        "*.old"
        "*.gz"
        "*.tar"
        "*.zip"
        "*.core"
    )
    
    # Ukuran file minimal yang mau dihapus (dalam MB)
    UKURAN_MINIMAL=100
    
    # Bikin pola buat perintah find
    POLA_CARI=""
    for pola in "${POLA_SAMPAH[@]}"; do
        if [ -z "$POLA_CARI" ]; then
            POLA_CARI="-name \"$pola\""
        else
            POLA_CARI="$POLA_CARI -o -name \"$pola\""
        fi
    done
    
    # Cari dan hapus file sampah yang gede
    PERINTAH="find / -type f $$ $POLA_CARI $$ -size +${UKURAN_MINIMAL}M -ls 2>/dev/null"
    tulis_log "Jalanin: $PERINTAH"
    
    FILE_SAMPAH_GEDE=$(eval "$PERINTAH")
    
    if [ -n "$FILE_SAMPAH_GEDE" ]; then
        tulis_log "Nemu file sampah gede nih:"
        tulis_log "$FILE_SAMPAH_GEDE"
        
        # Hapus filenya
        PERINTAH="find / -type f $$ $POLA_CARI $$ -size +${UKURAN_MINIMAL}M -delete 2>/dev/null"
        eval "$PERINTAH"
        tulis_log "Udah dihapus semua tuh file sampah"
    else
        tulis_log "Ga nemu file sampah gede, udah bersih keknya"
    fi
    
    tulis_log "Beres dah bersihin file sampah"
}

# Fungsi buat jalanin semua tugas pembersihan
bersihin_semua() {
    tulis_log "Mulai bersihin VPS..."
    bersihin_cache
    hapus_file_sampah
    tulis_log "Beres dah bersihin VPS"
}

# Fungsi buat setting PM2 startup
setting_pm2_startup() {
    tulis_log "Setting PM2 startup..."
    
    # Cek apakah PM2 ada
    if command -v pm2 &> /dev/null; then
        PM2_PATH="$(command -v pm2)"
        tulis_log "PM2 ditemukan di: $PM2_PATH"
    elif [ -f "$PM2_PATH" ]; then
        tulis_log "PM2 ditemukan di path yang dikonfigurasi: $PM2_PATH"
    else
        tulis_log "PM2 ga ketemu! Coba cari di path lain..."
        POSSIBLE_PATHS=(
            "/usr/bin/pm2"
            "/usr/local/bin/pm2"
            "/root/.npm-global/bin/pm2"
            "/home/$(whoami)/.npm-global/bin/pm2"
            "$(npm bin -g)/pm2"
        )
        
        for path in "${POSSIBLE_PATHS[@]}"; do
            if [ -f "$path" ]; then
                PM2_PATH="$path"
                tulis_log "PM2 ditemukan di: $PM2_PATH"
                break
            fi
        done
        
        if [ ! -f "$PM2_PATH" ]; then
            tulis_log "PM2 ga ketemu! Pastiin PM2 udah diinstall."
            return 1
        fi
    fi
    
    # Bikin script startup PM2
    tulis_log "Bikin script startup PM2..."
    
    PM2_STARTUP_SCRIPT="/root/pm2-startup.sh"
    
    cat > "$PM2_STARTUP_SCRIPT" << EOF
#!/bin/bash
# Script buat jalanin PM2 setelah reboot

# Tunggu 30 detik biar sistem stabil dulu
sleep 30

# Log
echo "\$(date '+%Y-%m-%d %H:%M:%S') - Mulai jalanin PM2..." >> $FILE_LOG

# Cek apakah api.js udah jalan
if $PM2_PATH list | grep -q "api"; then
    echo "\$(date '+%Y-%m-%d %H:%M:%S') - api.js udah jalan, restart aja..." >> $FILE_LOG
    cd /root/ && $PM2_PATH restart api >> $FILE_LOG 2>&1
else
    echo "\$(date '+%Y-%m-%d %H:%M:%S') - api.js belom jalan, start dulu..." >> $FILE_LOG
    cd /root/ && $PM2_PATH start api.js >> $FILE_LOG 2>&1
fi

# Save process list
$PM2_PATH save >> $FILE_LOG 2>&1

echo "\$(date '+%Y-%m-%d %H:%M:%S') - PM2 startup selesai" >> $FILE_LOG
EOF
    
    chmod +x "$PM2_STARTUP_SCRIPT"
    tulis_log "Script startup PM2 udah dibuat di $PM2_STARTUP_SCRIPT"
    
    # Setup PM2 untuk startup otomatis
    tulis_log "Setup PM2 untuk startup otomatis..."
    
    # Save current process list
    $PM2_PATH save 2>/dev/null || true
    
    # Generate startup script
    STARTUP_CMD=$($PM2_PATH startup 2>/dev/null | grep -o "sudo .*" || echo "")
    
    if [ -n "$STARTUP_CMD" ]; then
        tulis_log "Jalanin perintah startup PM2: $STARTUP_CMD"
        eval "$STARTUP_CMD" 2>/dev/null || true
    fi
    
    tulis_log "PM2 startup udah di-setting"
    return 0
}

# Fungsi buat setting jadwal di cron
setting_cron() {
    tulis_log "Setting jadwal di cron..."
    
    # Bikin file sementara buat crontab
    CRON_TEMP="/tmp/crontab.tmp"
    
    # Ambil crontab yang udah ada
    crontab -l > "$CRON_TEMP" 2>/dev/null || echo "" > "$CRON_TEMP"
    
    # Tambahin jadwal bersihin tiap jam kalo belom ada
    if ! grep -q "cleaner.sh bersih" "$CRON_TEMP"; then
        echo "0 * * * * /root/cleaner.sh bersih >> $FILE_LOG 2>&1" >> "$CRON_TEMP"
        tulis_log "Udah ditambahin jadwal bersihin tiap jam"
    fi
    
    # Tambahin jadwal restart tengah malem WIB (jam 17:00 UTC) kalo belom ada
    if ! grep -q "cleaner.sh restart" "$CRON_TEMP"; then
        echo "0 17 * * * /root/cleaner.sh restart >> $FILE_LOG 2>&1" >> "$CRON_TEMP"
        tulis_log "Udah ditambahin jadwal restart jam 12 malem WIB"
    fi
    
    # Tambahin perintah yang jalan abis restart kalo belom ada
    if ! grep -q "pm2-startup.sh" "$CRON_TEMP"; then
        echo "@reboot /root/pm2-startup.sh" >> "$CRON_TEMP"
        tulis_log "Udah ditambahin perintah jalanin PM2 abis reboot"
    fi
    
    # Tambahin perintah buat setting ulang cron abis restart (buat jaga-jaga)
    if ! grep -q "@reboot /root/cleaner.sh cek_cron" "$CRON_TEMP"; then
        echo "@reboot /root/cleaner.sh cek_cron >> $FILE_LOG 2>&1" >> "$CRON_TEMP"
        tulis_log "Udah ditambahin perintah cek cron abis reboot"
    fi
    
    # Pasang crontab baru
    crontab "$CRON_TEMP"
    rm "$CRON_TEMP"
    
    tulis_log "Jadwal udah diatur semua, mantap!"
}

# Fungsi buat cek status cron service
cek_cron_service() {
    tulis_log "Ngecek status service cron..."
    
    # Cek status cron service
    if systemctl is-active --quiet cron || systemctl is-active --quiet crond; then
        tulis_log "Service cron udah jalan, aman!"
    else
        tulis_log "Service cron belom jalan, nyalain dulu..."
        systemctl start cron 2>/dev/null || systemctl start crond 2>/dev/null
        
        if systemctl is-active --quiet cron || systemctl is-active --quiet crond; then
            tulis_log "Service cron udah dinyalain, mantap!"
        else
            tulis_log "GAGAL nyalain service cron! Perlu dicek manual nih."
        fi
    fi
}

# Fungsi buat cek dan pastiin cron jalan abis reboot
cek_cron() {
    tulis_log "Ngecek cron abis reboot..."
    
    # Cek service cron
    cek_cron_service
    
    # Cek jadwal di crontab
    CRON_TEMP="/tmp/crontab.tmp"
    crontab -l > "$CRON_TEMP" 2>/dev/null || echo "" > "$CRON_TEMP"
    
    # Cek apakah jadwal bersihin tiap jam ada
    if ! grep -q "cleaner.sh bersih" "$CRON_TEMP"; then
        tulis_log "Jadwal bersihin tiap jam ilang! Setting ulang..."
        setting_cron
    else
        tulis_log "Jadwal bersihin tiap jam masih ada, aman!"
    fi
    
    rm "$CRON_TEMP"
    tulis_log "Cek cron abis reboot selesai"
}

# Fungsi buat jalanin PM2
start_pm2() {
    tulis_log "Jalanin PM2..."
    
    # Cek apakah api.js udah jalan
    if $PM2_PATH list | grep -q "api"; then
        tulis_log "api.js udah jalan, restart aja..."
        cd /root/ && $PM2_PATH restart api
    else
        tulis_log "api.js belom jalan, start dulu..."
        cd /root/ && $PM2_PATH start api.js
    fi
    
    # Save process list
    $PM2_PATH save
    
    tulis_log "PM2 udah jalan"
}

# Eksekusi utama
case "$1" in
    bersih)
        # Jalanin pembersihan doang
        bersihin_semua
        ;;
    restart)
        # Bersihin dulu baru restart
        bersihin_semua
        tulis_log "Siap-siap restart VPS..."
        sync
        tulis_log "Data udah disync, restart sekarang..."
        /sbin/reboot
        ;;
    setting)
        # Setting jadwal cron dan PM2
        setting_cron
        setting_pm2_startup
        ;;
    cek_cron)
        # Cek cron abis reboot
        cek_cron
        ;;
    start_pm2)
        # Jalanin PM2
        start_pm2
        ;;
    status)
        # Cek status cron dan PM2
        cek_cron_service
        tulis_log "Jadwal yang aktif sekarang:"
        crontab -l | grep -E "cleaner.sh|pm2-startup.sh" | while read -r line; do
            tulis_log "- $line"
        done
        
        tulis_log "Status PM2:"
        $PM2_PATH list | while read -r line; do
            tulis_log "- $line"
        done
        ;;
    *)
        # Kalo ga ada parameter, setting semuanya
        tulis_log "Script Pembersih VPS Dimulai"
        setting_cron
        setting_pm2_startup
        cek_cron_service
        bersihin_semua
        tulis_log "Setting awal dan pembersihan udah beres"
        tulis_log "Pake 'cleaner.sh bersih' kalo mau bersihin manual"
        tulis_log "Pake 'cleaner.sh restart' kalo mau bersihin terus restart"
        tulis_log "Pake 'cleaner.sh status' kalo mau cek status cron dan PM2"
        tulis_log "Pake 'cleaner.sh start_pm2' kalo mau jalanin PM2 manual"
        ;;
esac

exit 0